function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	item:transform(22614)
	return true
end
