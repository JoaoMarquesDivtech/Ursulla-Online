function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	item:transform(24810)
	return true
end
