function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	item:transform(24809)
	return true
end
