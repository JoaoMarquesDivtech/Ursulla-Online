function onUse(player, item, fromPosition, target, toPosition, isHotkey)
	item:transform(25421)
	return true
end
