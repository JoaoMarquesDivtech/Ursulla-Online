
function onUse(cid, item, fromPosition, itemEx, toPosition)
doTeleportThing(cid, {x = 32401, y = 32794, z = 9})

return TRUE
end