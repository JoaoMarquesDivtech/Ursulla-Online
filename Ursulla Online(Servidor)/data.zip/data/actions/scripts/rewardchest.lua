function onUse(player, item)
    player:updateRewardChest()
    return false
end