function onUse(cid, item, fromPosition, itemEx, toPosition)
doPlayerSendTextMessage(cid, MESSAGE_INFO_DESCR, "Voce nao precisa passar nos testes para acessar o Santuario!")
return TRUE
end