function onUse(player, item, fromPosition, target, toPosition, isHotkey)

	onMiner(player, item, fromPosition, target, toPosition, isHotkey)
	onUsePick(player, item, fromPosition, target, toPosition, isHotkey)
	
end
