function onUse(player, item, fromPosition, target, toPosition, isHotkey)
        doTeleportThing(player, {x = 1081, y = 703, z = 10})
	return true
end
