function onLogin(cid)
doPlayerOpenChannel(cid, Help)
end